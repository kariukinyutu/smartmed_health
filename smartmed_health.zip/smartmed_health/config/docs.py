"""
Configuration for docs
"""

# source_link = "https://github.com/[org_name]/smartmed_health"
# headline = "App that does everything"
# sub_heading = "Yes, you got that right the first time, everything"

def get_context(context):
	context.brand_html = "Smartmed Health"
